﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LSConnect.Entities
{
    public class ErrorInfo
    {
        public int sqlID;
        public int? objID;
        public string externalID;
        public string errorMessage;

    }
}
