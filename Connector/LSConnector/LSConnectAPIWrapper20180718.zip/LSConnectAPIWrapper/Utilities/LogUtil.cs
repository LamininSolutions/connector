﻿using System;
using System.Collections.Generic;
////using System.Linq;
using System.Web;
//using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace LSConnect.Utilities
{
    //public class LogUtil
    //{
    //    public static void Log(string message)
    //    {
    //        LogEntry entry = new LogEntry();
    //        entry.Message = message;
    //        Logger.Write(entry);
    //    }
    //}
}