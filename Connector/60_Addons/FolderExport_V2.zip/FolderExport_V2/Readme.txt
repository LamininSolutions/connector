FOLDER AND FILES EXPORT UTILITY
Copywrite 2019 Laminin Solutions

SUMMARY
This utility will export structured folder and file data from explorer for a specific directory to a) CSV files b) tables in an SQL database.

PREREQUISITES
Powershell 5.0 + is required.
SQLServer module is required for the export to the SQL database
Run with windows credentials with access to SQL and the explorer file structure.
Access to SQL is based on using windows integrated security

PACKAGE CONTENT
FolderExport_Main.ps1 : this is the main routine.  Use FolderExport.bat to execute.
FolderExport.bat : used to execute the main routine. Refer to different section for modifying bat file.
FolderListExport.XML : the main configuration file. Refer to different section to setup.
\Library\ : the library contains the functions calls by the main routine.
\Log\ : error and processing log. folder is created by utility and level of logging is dependent on the options selected in the bat file.
\CSV\: csv output for the folder and file listing. file name is set in configuration file.

SETUP
Open FolderlistExport.xml with notepad or a xml editor.
modify the FileImporter\ApplicationPath to match the filepath where this utility is saved.
modify FileImporter\Folders\Folder\Root to the root filepath where the files and folders for exporting is located
modify FileImporter\Folders\Folder\ShortName to set the name of the CSV file and Database Table name.
modify FileImporter\TargetDB\Server to set the target server for the SQL destination
modify FileImporter\TargetDB\Database to set the name of the Database to export to.

BAT FILE
Open FolderExport.bat with notepad 
modify the string after -Command to reference the path of the main routine.
Note this command line is set to use basic process logging (the default parameter)

TO INSTALL MODULES
Run \library\FE_Module_install in powershell as administrator



