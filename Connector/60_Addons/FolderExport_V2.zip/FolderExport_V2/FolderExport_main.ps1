
# FolderExport_main.ps1
# Main process

Param([parameter(Mandatory=$true)][string]$SetupXML,[bool]$IsFullUpdate=$True,[bool]$IsDetailLogging = $False,[bool]$IncludeDatabaseUpdate = $False)

If ($SetupXML -eq $null)
{ write-host 'Invalid file parapmeter'
exit}
write ("Setup file : {0}" -f $SetupXML)
#Pause


if ($PSVersionTable.PSVersion.Major -lt 5)
{ Write "Current version of Powershell is incompatiple, upgrade to version 5 or higher"
Exit
}


# region Include required files
#
$ScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
try {
	
#	. ("$ScriptDirectory\LS_Functions_Lib.ps1")
    . ("$ScriptDirectory\Library\FE_Functions_Lib.ps1")
	. ("$ScriptDirectory\Library\FE_SQL_Procs.ps1")
#	. ("$ScriptDirectory\MainForm_2.designer.ps1")

#$MainForm_2.ShowDialog()
}
catch {
    Write-Host "Error while loading supporting PowerShell Scripts" 
    get-location
    exit
}
#endregion
Try {
$RootPath = Get-RootPath 
#write-host $RootPath
$Filename = Get-SetupFilePath $RootPath $SetupXML 

}
Catch
{ Write-Host "Unable to find XML"
}

##setup application settings
$ApplicationSettings = Get-ApplicationSettings($Filename)
write-host $ApplicationSettings

##Start logging
$Logging = Get-LoggingFolders $RootPath $ApplicationSettings.LogFolder 
$ErrorLog = $Logging[0]
$ProcessLog = $Logging[1]
##setup CSV file location

$CSVPath = join-path -path $RootPath -ChildPath '\CSV'
if(-NOT(Test-Path -path "$CSVPath" -PathType Container))
{new-Item  -path "$CSVPath" -itemType Directory
}


Try {
	$Message = "Start Processing: "+$ApplicationSettings."Application"
Add-ProcessLog $Message $True $ProcessLog
#$ApplicationSettings.Application
	}
	Catch
	{Write-Host "Unable to update log: $_"}
##Get Process ID
##Try {
##$SQLProcOutput = Invoke-SQLOutputProc -Server $ApplicationSettings.Server -Database $ApplicationSettings.Database -ProcName '[Expl].[usp_SetProcessID]' -OutputParamName '@ProcessID' -OutputParamDataType 'Int32'
##$ProcessID = $SQLProcOutput.GetValue(1)
##Add-ProcessLog "Process_ID: $ProcessID" $True $ProcessLog
##}Catch 
##{Write-Host "Unable to get process id: $_"}

##Add Settings
##Try {
##	Add-ProcessLog "Add Settings: " $True $ProcessLog

##	Add-SettingsRecord $ApplicationSettings $True
##}
##Catch {

##Add-ErrorLog "Unable to add settings $_"

##}
##Add Directory Records to temp CSV


Try {
$Location = $ApplicationSettings.Root

$CSVFileName = "\CSV\Folders_"+$ApplicationSettings.ShortName+".csv"
write ("Creating CSV file : {0} for directory listing of : {1}" -f ($CSVFileName,$Location) )
Add-ProcessLog "Start folder Update: " $False $ProcessLog

$CSVPath = join-path -path $RootPath -ChildPath $CSVFileName
$FolderCSVFileName = $CSVPath

$DirectoryList = Get-DirectoryList $Location $CSVPath

$RecCount = $Directorylist.Count

#Add-DirectoryRecord $DirectoryList $IsFullUpdate
Add-ProcessLog "Added Folder Records: $RecCount" $True $ProcessLog
write ("Created {0} folder entries" -f ($RecCount) )

}
Catch {Add-ErrorLog("Unable to add Directory Records",$_,"Function_AddDirectoryRecord" )

}

## Add File Records
Try {

$Location = $ApplicationSettings.Root
$CSVFileName = "\CSV\Files_"+$ApplicationSettings.ShortName+".csv"
write ("Creating CSV file : {0} for file listing of : {1}" -f ($CSVFileName,$Location) )


$CSVPath = join-path -path $RootPath -ChildPath $CSVFileName

Add-ProcessLog "Start File Update: "  $True $ProcessLog

$Folderlist = get-FileList $Location $CSVPath
$RecCount = $Folderlist.Count


Add-ProcessLog "Added Files Records: $RecCount" $True $ProcessLog
write ("Created {0} files entries" -f ($RecCount) )
}
Catch {Add-ErrorLog "Unable to add File Records $_" 

}

##Add CSV files to Database
## this requires the installation of SqlServer module

If ($IncludeDatabaseUpdate)
{
if(get-Module -List | Where-Object -Property name -eq 'SqlServer')
{
Try{

$Table = "Staging_Folders_"+ $ApplicationSettings.ShortName
write ("Uploading Folder CSV to {0}" -f ($Table) )

Import-CsvToSQLTable $ApplicationSettings.Server $ApplicationSettings.Database 'Expl' $table $FolderCSVFileName

}Catch
{
Add-ErrorLog "Unable to Upoad Folder CSV to Database $_" 
}


Try{

$Table = "Staging_Files_"+ $ApplicationSettings.ShortName
write ("Uploading File CSV to {0}" -f ($Table) )
Import-CsvToSQLTable $ApplicationSettings.Server $ApplicationSettings.Database 'Expl' $table $FileCSVFileName

}Catch
{
Add-ErrorLog "Unable to Upoad File CSV to Database $_" 
}
}
Else
{ Write "SqlServer module is not installed - database tables not created"}

Else
{
Write "Skipped database update"
}
}

