#
# FE_Function_Lib.ps1
#

#region Get root path
Function Get-RootPath()
{
 $RootPath = if ($psISE)
{
   Split-Path -Path $psISE.CurrentFile.FullPath        
}
else
{
 #  Get-Location
 $MyInvocation.PSScriptRoot
#	Split-Path -Path $MyInvocation.MyCommand.Definition 

#    $global:PSScriptRoot
}
return $RootPath 
}
#endregion

#region Setup file name
Function Get-SetupFilePath($RootPath, $SetupXML)
{
$Filename = join-Path $RootPath -childpath $SetupXML
if (!(Test-Path $Filename -PathType Any)) {
add-SetupFile $SetupXML $RootPath
    Write-Host "New setup file : $FileName created"
	}
Return $Filename
}

#endregion

#region add setup file

Function add-SetupFile($Filename,$RootPath)
{
$XMLDoc = new-Object System.Xml.XmlDocument

$XMLDoc = [XML]('<FileImporter/>')

$Def = $XMLDoc.CreateElement('Definition')
$Folders = $XMLDoc.CreateElement('Folders')
$Folder = $XMLDoc.CreateElement('Folder')
$TargetDB = $XMLDoc.CreateElement('TargetDB')
$Folders.AppendChild($Folder) | Out-Null 

$ApplicationPath = Split-Path -Path $MyInvocation.PSScriptRoot
$Def.SetAttribute("Owner","Laminin Solutions")
$Def.SetAttribute("LogFolder","Logs")
$Def.SetAttribute("ApplicationPath",$ApplicationPath)

$Folder.SetAttribute("Root",$RootPath)
$Folder.SetAttribute("PathDepth","3")
$Folder.SetAttribute("ShortName","TestData")

$TargetDB.SetAttribute("Server","ServerName")
$TargetDB.SetAttribute("Database","DatabaseName")

$XMLDoc.DocumentElement.AppendChild($Def) | Out-Null
$XMLDoc.DocumentElement.AppendChild($Folders) | Out-Null
$XMLDoc.DocumentElement.AppendChild($TargetDB) | Out-Null

	"$RootPath\$filename"

#	join-path -path $Path -ChildPath $FileName

$filePath = "$RootPath\$filename"
$XMLDoc.Save($filePath)

write "New Setup file is created, update setup then run again"
exit
}
#endregion

#region get application settings

Function Get-ApplicationSettings($Filename)
{

[xml]$XmlDocument = $null
[xml]$XmlDocument = Get-Content -Path "$Filename"


$ApplicationSettings = new-Object -TypeName psobject -Property 	@{"Application" = $XmlDocument.FileImporter.Definition.Application;
		"LogFolder" = $XmlDocument.FileImporter.Definition.LogFolder;
		"ApplicationPath" = $XmlDocument.FileImporter.Definition.ApplicationPath;
		"Root" = $XmlDocument.FileImporter.Folders.Folder.Root;
		"ShortName"= $XmlDocument.FileImporter.Folders.Folder.ShortName;
		"Server" = $XmlDocument.FileImporter.TargetDB.Server;
		"Database" = $XmlDocument.FileImporter.TargetDB.Database		 
}

	Return $ApplicationSettings
}
#endregion

#region get logging folders

Function Get-LoggingFolders($RootPath,$LogPath)
{

$AppPath = join-path -path $RootPath -ChildPath $LogPath 
if(-NOT(Test-Path -path "$AppPath" -PathType Container))
{new-Item  -path "$AppPath" -itemType Directory
}

##Logging
Try {
$ErrorLog  = join-path -Path $RootPath -childPath "$LogPath\ErrorLog.txt"
$ProcessLog  = join-path -Path $RootPath -childpath "$LogPath\ProcessLog.txt"

}
Catch
{Write-Host "Get Log folders fail: $LogPath $_"
}
if (Test-Path $ErrorLog ) {
   Clear-Content $ErrorLog
	}

if (Test-Path $ProcessLog ) {
   Clear-Content $ProcessLog
	}
	Return $ErrorLog,$ProcessLog
}
#endregion

#region add error log

Function Add-ErrorLog($ErrorMessage,$Error,$LogReference)
{
$ProcessDate = Get-Date
write-host "$ProcessDate : $ErrorMessage $Error  " 
#| Add-Content $Logging[0]
}
#endregion

#region add process log

Function Add-ProcessLog($ProcessMessage,[bool]$DetailLevel,$Path)
{

Try {

	$ProcessDate = Get-Date
	if($DetailLevel){
"$ProcessDate : $ProcessMessage" | Add-Content $Path
		}
}
Catch 
{Write-Host "Process Log fail: $ProcessMessage $Path $_"}

}
#endregion

#region get directories

Function Get-DirectoryList($Location,$CSVPath)
{

set-location $Location
Try
{
Get-ChildItem -Force -recurse  | ForEach-Object -Process {
if ($_.PSIsContainer)
{
$IsCharException = Resolve-SpecialCharException $_."Name"

If (-NOT($IsCharException))
{
 $PartPath =  $_.Name
 $PartPath = $PartPath -Replace [regex]::Escape($Location),""

$ItemRow = New-Object -TypeName PSObject
$ItemRow | add-Member -MemberType NoteProperty -Name Path -Value $PartPath
$ItemRow | add-Member -MemberType NoteProperty -Name Drive -Value $_.Root
$ItemRow | add-Member -MemberType NoteProperty -Name Parent -Value $_.Parent
$ItemRow | add-Member -MemberType NoteProperty -Name Folder -Value $_.Name
$ItemRow | add-Member -MemberType NoteProperty -Name FullPath -Value $_.FullName
$ItemRow | add-Member -MemberType NoteProperty -Name FileCount -Value $_.Count
$ItemRow | add-Member -MemberType NoteProperty -Name Root -Value $Location

#$ItemRow

Out-ObjectToCSV $ItemRow $CSVPath

}

}
}

Add-ProcessLog "Start Directory Update: " $False $ProcessLog
Add-DirectoryRecord $ItemRow $IsFullUpdate
Add-ProcessLog "Added Directory Records: $RecCount" $True $ProcessLog

}
Catch {
Add-ErrorLog("Unable to add Directory Records",$_,"Function_AddDirectoryRecord" )
#write $Error
}
#Return $DirectoryList
}

#endregion

#region get file list

Function Get-FileList($Location, $CSVPath)
{
Try
{
set-location $Location

Get-ChildItem -Force -recurse | ForEach-Object -Process {
if (-not($_.PSIsContainer))
{

#$RecCount = $Files.Count

#$FileList = @() 

$IsCharException = Resolve-SpecialCharException $_."Name"

If (-NOT($IsCharException))
{
 $PartPath =  (Get-ItemPropertyValue $_.FullName -Name Directory)
 $PartPath = $PartPath -Replace [regex]::Escape($Location),""

$ItemRow = New-Object -TypeName PSObject
$ItemRow | add-Member -MemberType NoteProperty -Name FileName -Value $_.Name
$ItemRow | add-Member -MemberType NoteProperty -Name Extension -Value $_.Extension
$ItemRow | add-Member -MemberType NoteProperty -Name SubPath -Value $PartPath
#$ItemRow | add-Member -MemberType NoteProperty -Name FilePath -Value (Get-ItemPropertyValue $_.FullName -Name Directory)
$ItemRow | add-Member -MemberType NoteProperty -Name FullPath -Value $_.FullName 
$ItemRow | add-Member -MemberType NoteProperty -Name Length -Value $_.Length
$ItemRow | add-Member -MemberType NoteProperty -Name Creation -Value $_.CreationTimeUtc
$ItemRow | add-Member -MemberType NoteProperty -Name LastAccess -Value $_.LastAccessTimeUtc
$ItemRow | add-Member -MemberType NoteProperty -Name LastWrite -Value $_.LastWriteTimeUtc
$ItemRow | add-Member -MemberType NoteProperty -Name Attributes -Value $_.Attributes
$ItemRow | add-Member -MemberType NoteProperty -Name IsContainer -Value $_.PSIsContainer
$ItemRow | add-Member -MemberType NoteProperty -Name RootPath -Value $Location
$ItemRow | add-Member -MemberType NoteProperty -Name Hash -Value (Get-StringHash -Strings $_.FullName -Algorithm "MD5").Hash


#$ItemRow.fileName

Out-ObjectToCSV $ItemRow $CSVPath

}

}

#Add-ProcessLog "Start Directory Update: " $False $ProcessLog
#Add-DirectoryRecord $DirectoryList $IsFullUpdate
#Add-ProcessLog "Added Directory Records: $RecCount" $True $ProcessLog

}

}
Catch {Add-ErrorLog("Unable to add File Records",$_.name,"Function_GetFileRecord" )

#Return $FileList
}
}

#endregion

#region Object to CSV
Function Out-ObjectToCSV($ObjectList, $FileName)
{

#Write-Host "Script started..." 
#elapsed = [System.Diagnostics.Stopwatch]::StartNew()

#File exist, if not create

##if (Test-Path $FileName ) {
##   Clear-Content -force $FileName
##	}else
##{new-item -path $FileName -ItemType File
##}

$ObjectList | Export-CSV  -append -NoTypeInformation -force -path $FileName 

#Write-Host "Script complete. $i rows have been inserted into the CSV." 
#Write-Host "Total Elapsed Time: $($elapsed.Elapsed.ToString())" 
}

#endregion

#region resolve special character exceptions

Function Resolve-SpecialCharException($String)
{

$ExceptionList = "'"

if ($String -match $ExceptionList)
{
  write-output "$String : include exceptions: $_ : $ExceptionList"
  return $True 
}
else 
{
  return $False
}


}

#endregion

#region add settings record

Function Add-SettingsRecord($Settings,[bool]$IsFullUpdate)
{
	$params = @{'server'= $Settings.Server;'Database'=$Settings.Database}
	$Database = $Settings.Database + ".[Expl].[FolderSettings]"
	$Col3 = $Settings."ShortName" 
	$Settings | get-member -type NoteProperty | foreach-object {
  $Col1=$_.Name ; 
  $Col2=$Settings."$($_.Name)"

$Query = @"
MERGE INTO $Database t
USING (SELECT '$Col1' As Col1,'$Col2' as Col2,'$Col3' as Col3) S 
ON [t].[SettingsName] = [S].[Col1] and t.[Scope] = s.Col3
WHEN MATCHED THEN 
UPDATE SET
t.SettingsValue = s.Col2	 
WHEN NOT MATCHED 
THEN INSERT
(SettingsName,SettingsValue,Scope)
VALUES (s.Col1,s.Col2,s.Col3) 
;
"@

Try {

 Invoke-sqlcmd @params -Query $Query -ErrorAction Stop

	if ($IsDetailLogging){
Add-ProcessLog "Setting Updated: $Col1" $IsDetailLogging $ProcessLog
		}
}
Catch
{
Add-ErrorLog "Upsert Settings Failed: $_ $Query"
}
}
}

#endregion

#region add file record

Function Add-FileRecord($FolderList,$IsFullUpdate)
{
	$params = @{'server'= $ApplicationSettings.Server;'Database'=$ApplicationSettings.Database}
	$Database = $ApplicationSettings.Database + ".[Expl].[FileIndex]"



foreach ($item in $Folderlist)
{
#{Write-Progress -Activity "Search in Progress" -Status "$I% Complete:" -PercentComplete $I;}
$IsCharException = Resolve-SpecialCharException $item."FullName"

If (-NOT($IsCharException))
{

$Col1 = $item."FullName" 
$Col2 = $item."Name" 
$Col3 = $item."Extension"
$Col4 = $item."CreationTimeUtc"
$Col5 = $item."LastAccessTimeUtc"
$Col6 = $item."LastWriteTimeUtc"
$Col7 = $item."Attributes"
$Col8 = $item."PSIsContainer"
$Col10 = $item."Length"
$Col11 = (Get-FileHash $item."FullName").Hash
$Col12 = $ApplicationSettings."ShortName"
	

Try
	{
$Col9=(Get-ItemPropertyValue $item.FullName -Name Directory) 
		}
	Catch
	{
		
	}


$Query = @"
MERGE INTO $Database t
USING (SELECT '$Col1' As FullName,'$Col2' as Name,'$Col3' as Extension,'$Col4' as CreationTimeUtc,'$Col5' as LastAccessTimeUtc,'$Col6' as LastWriteTimeUtc,'$Col7' as Attributes,'$Col8'  as PSIsContainer, '$Col9' as FileDirectory, '$Col10' as [Length],'$Col11' as [Hash], '$Col12' as ShortName, '$ProcessID' as UpdateID ) S 
ON [t].[PathName] = [S].[FullName] and t.ShortName = s.ShortName
WHEN MATCHED THEN 
UPDATE SET
t.LastAccessTimeUtc = s.LastAccessTimeUtc
,t.LastWriteTimeUtc = s.LastWriteTimeUtc
,t.FileHash = s.Hash
,t.UpdateID = s.UpdateID		 
WHEN NOT MATCHED 
THEN INSERT
(PathName,FileName,Extension,CreationTimeUtc,LastAccessTimeUtc,LastWriteTimeUtc,Attributes,PSIsContainer,FileDirectory,Length,FileHash, ShortName, UpdateID)
VALUES ('$Col1','$Col2','$Col3','$Col4','$Col5','$Col6','$Col7','$Col8','$Col9','$Col10','$Col11','$Col12','$ProcessID') 
;
"@

Try {
	if ($IsFullUpdate){

 Invoke-sqlcmd @params -Query $Query -ErrorAction Stop
		}
	if ($IsDetailLogging){
Add-ProcessLog "Files Updated: $Col1" $IsDetailLogging $ProcessLog
		}

}
Catch
{
Add-ErrorLog "Upsert Files Failed $_ $Query"
}}Else
{
Add-ErrorLog "Special Char Exception: $Col1"
}
}
Try
	{
$Proc = Invoke-SQLUpdateProcessProc -Server $ApplicationSettings.Server -Database $ApplicationSettings.Database -ProcName '[Expl].[usp_UpdateProcessID]' -Param1 @ProcessID -Param2 '1' -Param3 $ApplicationSettings.ShortName
		
	}Catch 
{Write-Host "Unable to Update process id: $_"}
}
#endregion

#region add directory record

Function Add-DirectoryRecord($DirectoryList,$IsFullUpdate)
{
	
	$params = @{'server'= $ApplicationSettings.Server;'Database'=$ApplicationSettings.Database}
	$Database = $ApplicationSettings.Database + ".[Expl].[Directories]"

foreach($item in $DirectoryList)
{
#{Write-Progress -Activity "Search in Progress" -Status "$I% Complete:" -PercentComplete $I;}
$IsCharException = Resolve-SpecialCharException $item."Name"

If (-NOT($IsCharException))
{

$Col1 = $Item.Name 
$Col2 = $Item.Count
$Col3 = $Item.Values.BaseName 
$Col4 = $Item.Values.Parent.Name 
$Col5 = $ApplicationSettings."ShortName"

#	$Col1,$Col2,$Col3,$Col4

$Query = @"
MERGE INTO $Database t
USING (SELECT '$Col1' AS Name, '$Col2' AS [Count],'$Col3' as FolderName,'$Col4' as ParentFolder,'$Col5' as ShortName,'$ProcessID' as UpdateID ) S 
ON [t].[RootPath] = [S].[Name] and t.ShortName = s.ShortName
WHEN MATCHED THEN 
UPDATE SET
t.[FileCount] = S.[Count],t.FolderName= s.FolderName, t.ParentFolder = s.ParentFolder,t.UpdateID = s.UpdateID
WHEN NOT MATCHED 
THEN INSERT
(RootPath, [Filecount], FolderName, ParentFolder, ShortName, UpdateID)
VALUES
(s.Name, S.[Count],s.FolderName, s.ParentFolder, s.ShortName, s.UpdateID) 
;
"@

Try {
	If ($IsFullUpdate){
 Invoke-sqlcmd @params -Query $Query -ErrorAction Stop
		}
	if ($IsDetailLogging){
	Add-ProcessLog "Directory Updated: $Col1" $IsDetailLogging $ProcessLog
		}
}
Catch
{
Add-ErrorLog "Upsert Directory Failed $_ $Query"
}}Else
{
Add-ErrorLog "Special Char Exception: $Col1"
}
}
}
#endregion

#region select custom object

Function selectCustomObject()
{
	
#$ApplicationSettings | get-member -type NoteProperty | Where-Object {$_.Name -eq 'Root'} | ForEach-object { $name = $_.Name;
# $Location = $ApplicationSettings."$($_.Name)"  }

}
#endregion

#region export rec to csv

function add-ObjectToSCV()
{
	
}
#endregion

#region  elevate rights to administrator

function set-ElevatedRights()
{
# Get the ID and security principal of the current user account
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
 
# Get the security principal for the Administrator role
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
 
# Check to see if we are currently running "as Administrator"
if ($myWindowsPrincipal.IsInRole($adminRole))
   {
   # We are running "as Administrator" - so change the title and background color to indicate this
   $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   $Host.UI.RawUI.BackgroundColor = "DarkBlue"
   clear-host
   }
else
   {
   # We are not running "as Administrator" - so relaunch as administrator
   
   # Create a new process object that starts PowerShell
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
   
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
   
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
   
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);
   
   # Exit from the current, unelevated, process
   exit
   }
 
# Run your code that needs to be elevated here
Write-Host -NoNewLine "Press any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
#endregion


#region get stringhash
Function Get-StringHash {
<#
.SYNOPSIS
    This function returns the hash of a string 
    using the specified hashing algorithm.
.DESCRIPTION
    This function returns the hash of a string 
    using the specified hashing algorithm.

    The hash will be returned as a hexadecimal
    string.
.PARAMETER Strings
    This parameter should contain the strings 
    for which you need a hash value.
.PARAMETER Algorithm
    This parameter specifies the hashing algorithm
    you want to use.

    The allowed values are:
        * MD5
        * SHA1
        * SHA256
        * SHA384
        * SHA512
.PARAMETER ToLower
    This parameter has the hash converted to 
    lowercase.  The default is to output the hash
    in uppercase.
.INPUTS
    System.String
.OUTPUTS
    System.String
.LINK
    http://msdn.microsoft.com/en-us/library/system.security.cryptography.hashalgorithm.aspx
.EXAMPLE
    C:\ PS>Get-StringHash -Strings "hello" -Algorithm "MD5"
    5D41402ABC4B2A76B9719D911017C592
.EXAMPLE
    C:\ PS>Get-StringHash -Strings "hello" -Algorithm "SHA256"
    2CF24DBA5FB0A30E26E83B2AC5B9E29E1B161E5C1FA7425E73043362938B9824
.EXAMPLE
    C:\ PS>"hello","goodbye" | Get-StringHash -Algorithm "MD5"
    5D41402ABC4B2A76B9719D911017C592
    69FAAB6268350295550DE7D587BC323D
#>
[CmdletBinding()]
Param(
    [Parameter(
        Mandatory=$True,
        Position=0,
        ValueFromPipeline=$True
    )]
    [String[]]
    $Strings,

    [Parameter(
        Mandatory=$True,
        Position=1
    )]
    [ValidateSet("MD5","SHA1","SHA256","SHA384","SHA512")]
    [String]
    $Algorithm,

    [Switch]
    $ToLower
)
Begin {
    Switch ($Algorithm) {
        "MD5" {
            $hasher = New-Object -TypeName `
                "System.Security.Cryptography.MD5CryptoServiceProvider"
            Break
        }
        "SHA1" {
            $hasher = New-Object -TypeName `
                "System.Security.Cryptography.SHA1CryptoServiceProvider"
            Break
        }
        "SHA256" {
            $hasher = New-Object -TypeName `
                "System.Security.Cryptography.SHA256CryptoServiceProvider"
            Break
        }
        "SHA384" {
            $hasher = New-Object -TypeName `
                "System.Security.Cryptography.SHA384CryptoServiceProvider"
            Break
        }
        "SHA512" {
            $hasher = New-Object -TypeName `
                "System.Security.Cryptography.SHA512CryptoServiceProvider"
            Break
        }
    }
    $encoding = [System.Text.Encoding]::UTF8
}
Process {
    ForEach($String in $Strings){
        $hash = ($hasher.ComputeHash($encoding.GetBytes($String)) | % {
            "{0:X2}" -f $_
        }) -join ""

        If($ToLower){
            [String]$hash.toLower()
        } Else {
            [String]$hash
        }
    }
}
}

#endregion

