#
# FE_SQL_Procs.ps1
#

#region Get Output proc
Function Invoke-SQLOutputProc($Server, $Database, $ProcName, $OutputParamName, $OutputParamDataType)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $ProcName
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
$outParameter = new-object System.Data.SqlClient.SqlParameter;
$outParameter.ParameterName = $OutputParamName;
$outParameter.Direction = [System.Data.ParameterDirection]'Output';
$outParameter.DbType = [System.Data.DbType]$OutputParamDataType;
$outParameter.Size = 200;
$SqlCmd.Parameters.Add($outParameter);
$SqlConnection.Open();
$result = $SqlCmd.ExecuteNonQuery();
$output = $SqlCmd.Parameters[$OutputParamName].Value;
$SqlConnection.Close();
Return $output;
	}
	#endregion

#region update proc
	
Function Invoke-SQLUpdateProcessProc($Server, $Database, $ProcName, $Param1, $Param2, $Param3)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $ProcName
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
$Parameter1 = new-object System.Data.SqlClient.SqlParameter;
$Parameter1.ParameterName = '@ID';
$Parameter1.Value = $Param1
#$Parameter1.Direction = [System.Data.ParameterDirection]'Output';
$Parameter1.DbType = [System.Data.DbType]'Int32';
#$outParameter1.Size = 100;
$SqlCmd.Parameters.Add($Parameter1);
$Parameter2 = new-object System.Data.SqlClient.SqlParameter;
$Parameter2.ParameterName = '@UpdateFlag';
$Parameter2.Value = $Param2
$Parameter2.DbType = [System.Data.DbType]'Int32';
#$outParameter2.Size = 100;
$SqlCmd.Parameters.Add($Parameter2);
$Parameter3 = new-object System.Data.SqlClient.SqlParameter;
$Parameter3.ParameterName = '@Update';
$Parameter3.Value = $Param3
$Parameter3.DbType = [System.Data.DbType]'String';
$Parameter3.Size = 100;
$SqlCmd.Parameters.Add($Parameter3);
$SqlConnection.Open();
$result = $SqlCmd.ExecuteNonQuery();
#$output = $SqlCmd.Parameters[$OutputParamName].Value;
$SqlConnection.Close();
#Return $output;
	}

	#endregion

#region Import CSV with SQLServer module

Function Import-CsvToSQLTable($ServerInstance, $DatabaseName, $Schema, $TableName, $CSVFileName)
{
write ("Importing {0} into table {1}.{2} on database {3} " -f ($CSVFileName,$Schema,$TableName,$DatabaseName) ) 

Add-ProcessLog "Start Import: $TableName" $false $ProcessLog

$Query = @"
IF OBJECT_ID('$Schema.$TableName', 'U') IS NOT NULL 
TRUNCATE TABLE $Schema.$TableName;
"@
#write-host $Query

Try { 

	
Invoke-Sqlcmd -ServerInstance $ServerInstance -Database $DatabaseName -Query $Query  -ErrorAction Stop

Add-ProcessLog "Truncated table: $TableName" $true $ProcessLog


}
Catch
{
Write-Host "Truncate Failed $_ $Query"
Exit
}

Try {


,(Import-Csv -Path $CSVFileName) | Write-SqlTableData -ServerInstance $ServerInstance -DatabaseName $DatabaseName -SchemaName $Schema -TableName $TableName -Force

Add-ProcessLog "End Import: $TableName" $true $ProcessLog

}Catch
{
Write-Host "Update Table Failed $_ "
Exit
}
}

#endregion
