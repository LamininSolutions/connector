#
# FE_Function_Lib.ps1
#

#region Get root path
Function Get-RootPath()
{
 $RootPath = if ($psISE)
{
   Split-Path -Path $psISE.CurrentFile.FullPath        
}
else
{
 #  Get-Location
 $MyInvocation.PSScriptRoot
#	Split-Path -Path $MyInvocation.MyCommand.Definition 

#    $global:PSScriptRoot
}
return $RootPath 
}
#endregion

#region Setup file name
Function Get-SetupFilePath($RootPath, $SetupXML)
{
$Filename = join-Path $RootPath -childpath $SetupXML
if (!(Test-Path $Filename -PathType Any)) {
add-SetupFile $SetupXML $RootPath
    Write-Host "New setup file : $FileName created"
	}
Return $Filename
}

#endregion

#region add setup file

Function add-SetupFile($Filename,$RootPath)
{
$XMLDoc = new-Object System.Xml.XmlDocument

$XMLDoc = [XML]('<SQLScheduler/>')

$Def = $XMLDoc.CreateElement('Definition')
$TargetDB = $XMLDoc.CreateElement('TargetDB')
$Folders.AppendChild($Folder) | Out-Null 

$ApplicationPath = Split-Path -Path $MyInvocation.PSScriptRoot
$Def.SetAttribute("Owner","Laminin Solutions")
$Def.SetAttribute("LogFolder","Logs")
$Def.SetAttribute("ApplicationPath",$ApplicationPath)

$TargetDB.SetAttribute("Server","ServerName")
$TargetDB.SetAttribute("Database","DatabaseName")

$XMLDoc.DocumentElement.AppendChild($Def) | Out-Null
$XMLDoc.DocumentElement.AppendChild($TargetDB) | Out-Null

	"$RootPath\$filename"

#	join-path -path $Path -ChildPath $FileName

$filePath = "$RootPath\$filename"
$XMLDoc.Save($filePath)

write "New Setup file is created, update setup then run again"
exit
}
#endregion

#region get application settings

Function Get-ApplicationSettings($Filename)
{

[xml]$XmlDocument = $null
[xml]$XmlDocument = Get-Content -Path "$Filename"


$ApplicationSettings = new-Object -TypeName psobject -Property 	@{"Application" = $XmlDocument.SQLScheduler.Definition.Application;
		"LogFolder" = $XmlDocument.SQLScheduler.Definition.LogFolder;
		"ApplicationPath" = $XmlDocument.SQLScheduler.Definition.ApplicationPath;
		"Root" = $XmlDocument.SQLScheduler.Folders.Folder.Root;
		"ShortName"= $XmlDocument.SQLScheduler.Folders.Folder.ShortName;
		"Server" = $XmlDocument.SQLScheduler.TargetDB.Server;
		"Database" = $XmlDocument.SQLScheduler.TargetDB.Database		 
}

	Return $ApplicationSettings
}
#endregion

#region get logging folders

Function Get-LoggingFolders($RootPath,$LogPath)
{

$AppPath = join-path -path $RootPath -ChildPath $LogPath 
if(-NOT(Test-Path -path "$AppPath" -PathType Container))
{new-Item  -path "$AppPath" -itemType Directory
}

##Logging
Try {
$ErrorLog  = join-path -Path $RootPath -childPath "$LogPath\ErrorLog.txt"
$ProcessLog  = join-path -Path $RootPath -childpath "$LogPath\ProcessLog.txt"

}
Catch
{Write-Host "Get Log folders fail: $LogPath $_"
}
if (Test-Path $ErrorLog ) {
   Clear-Content $ErrorLog
	}

if (Test-Path $ProcessLog ) {
   Clear-Content $ProcessLog
	}
	Return $ErrorLog,$ProcessLog
}
#endregion

#region add error log

Function Add-ErrorLog($ErrorMessage,$Error,$LogReference)
{
$ProcessDate = Get-Date
"$ProcessDate : $ErrorMessage $Error  " | Add-Content $Logging[0]
}
#endregion

#region add process log

Function Add-ProcessLog($ProcessMessage,[bool]$DetailLevel,$Path)
{

Try {

	$ProcessDate = Get-Date
	if($DetailLevel){
"$ProcessDate : $ProcessMessage" | Add-Content $Path
		}
}
Catch 
{Write-Host "Process Log fail: $ProcessMessage $Path $_"}

}
#endregion

#region add settings record

Function Add-SettingsRecord($Settings,[bool]$IsFullUpdate)
{
	$params = @{'server'= $Settings.Server;'Database'=$Settings.Database}
	$Database = $Settings.Database + ".[Expl].[FolderSettings]"
	$Col3 = $Settings."ShortName" 
	$Settings | get-member -type NoteProperty | foreach-object {
  $Col1=$_.Name ; 
  $Col2=$Settings."$($_.Name)"

$Query = @"
MERGE INTO $Database t
USING (SELECT '$Col1' As Col1,'$Col2' as Col2,'$Col3' as Col3) S 
ON [t].[SettingsName] = [S].[Col1] and t.[Scope] = s.Col3
WHEN MATCHED THEN 
UPDATE SET
t.SettingsValue = s.Col2	 
WHEN NOT MATCHED 
THEN INSERT
(SettingsName,SettingsValue,Scope)
VALUES (s.Col1,s.Col2,s.Col3) 
;
"@

Try {

 Invoke-sqlcmd @params -Query $Query -ErrorAction Stop

	if ($IsDetailLogging){
Add-ProcessLog "Setting Updated: $Col1" $IsDetailLogging $ProcessLog
		}
}
Catch
{
Add-ErrorLog "Upsert Settings Failed: $_ $Query"
}
}
}

#endregion

#region select custom object

Function selectCustomObject()
{
	
#$ApplicationSettings | get-member -type NoteProperty | Where-Object {$_.Name -eq 'Root'} | ForEach-object { $name = $_.Name;
# $Location = $ApplicationSettings."$($_.Name)"  }

}
#endregion

#region  elevate rights to administrator

function set-ElevatedRights()
{
# Get the ID and security principal of the current user account
$myWindowsID=[System.Security.Principal.WindowsIdentity]::GetCurrent()
$myWindowsPrincipal=new-object System.Security.Principal.WindowsPrincipal($myWindowsID)
 
# Get the security principal for the Administrator role
$adminRole=[System.Security.Principal.WindowsBuiltInRole]::Administrator
 
# Check to see if we are currently running "as Administrator"
if ($myWindowsPrincipal.IsInRole($adminRole))
   {
   # We are running "as Administrator" - so change the title and background color to indicate this
   $Host.UI.RawUI.WindowTitle = $myInvocation.MyCommand.Definition + "(Elevated)"
   $Host.UI.RawUI.BackgroundColor = "DarkBlue"
   clear-host
   }
else
   {
   # We are not running "as Administrator" - so relaunch as administrator
   
   # Create a new process object that starts PowerShell
   $newProcess = new-object System.Diagnostics.ProcessStartInfo "PowerShell";
   
   # Specify the current script path and name as a parameter
   $newProcess.Arguments = $myInvocation.MyCommand.Definition;
   
   # Indicate that the process should be elevated
   $newProcess.Verb = "runas";
   
   # Start the new process
   [System.Diagnostics.Process]::Start($newProcess);
   
   # Exit from the current, unelevated, process
   exit
   }
 
# Run your code that needs to be elevated here
Write-Host -NoNewLine "Press any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}
#endregion

#region is MF version current

<#
This function will check the installed version of M-Files against the input parameter.
The return will show true if it is current, and it will also return the installed version

example
$Result = get-CurrentMfilesVersion('19.3.7499.4')
$Result[1]
$Result[0]


#>

function get-CurrentMfilesVersion($MFVersion)
{
$Key = "HKLM:\software\motive\M-Files"
$IsCurrent = $False
$InstVersion = get-Childitem $Key -Name 
$CurVersion = $Instversion[0]
If($CurVersion -eq $MFVersion)
{
$IsCurrent = $True
}
$Return = New-Object PSObject -Property @{isCurrent = $IsCurrent
 Value = $CurVersion}
return $Return
}


#endregion

#region show progress bar
function get-ProgressBar()
{
For ($I = 1; $I -le 100; $I++){
Write-Progress -Activity 'Processing in progress' -Status '$I% Complete:' -PercentComplete $I;}
}

#endregion
