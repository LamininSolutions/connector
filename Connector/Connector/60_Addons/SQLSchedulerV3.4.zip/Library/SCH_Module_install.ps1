﻿
## SqlServer must be install prior to running Folder Export and using SQL imprt
## This must be run in elevation (as admin)

Import-Module -Name SqlServer

Install-Module -Name SqlServer -AllowClobber

get-Module -List | Where-Object -Property name -eq 'SqlServer'

