#
# FE_SQL_Procs.ps1
#


#region Get Output proc
Function Invoke-SQLOutputProc($Server, $Database, $Procedure, $OutputParamName, $OutputParamDataType)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $ProcedureName
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
$outParameter = new-object System.Data.SqlClient.SqlParameter;
$outParameter.ParameterName = $OutputParamName;
$outParameter.Direction = [System.Data.ParameterDirection]'Output';
$outParameter.DbType = [System.Data.DbType]$OutputParamDataType;
$outParameter.Size = 200;
$SqlCmd.Parameters.Add($outParameter);
$SqlConnection.Open();
$result = $SqlCmd.ExecuteNonQuery();
$output = $SqlCmd.Parameters[$OutputParamName].Value;
$SqlConnection.Close() | out-Null;
$SqlCmd.Dispose() | out-Null
$SqlConnection.Dispose() | out-Null;

Return $output;
	}
	#endregion

#region Sql query

Function Invoke-SQLQueryProc($Server, $Database, $Query)
{

$QueryResult = Invoke-Sqlcmd -ServerInstance $Server -Database $Database -Query $query

Return $QueryResult

}

#endregion

#region invoke SQL procedure with no params
Function Invoke-SQLNoParamProc($Server, $Database, $ProcedureName)
{

$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $ProcedureName
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
$paramReturn = $SqlCmd.Parameters.Add("@ReturnValue", [System.Data.SQLDbType]"Int")
$paramReturn.Direction = [System.Data.ParameterDirection]"ReturnValue"
$SqlConnection.Open();
$result = $SqlCmd.ExecuteReader() 
$ReturnValue = [int]$SqlCmd.Parameters["@ReturnValue"].Value
#$output = $SqlCmd.Parameters[$OutputParamName].Value;
$SqlConnection.Close() | out-Null;
#$SqlCmd.Dispose() | out-Null
#$SqlConnection.Dispose() | out-Null;

Return $ReturnValue
}

#endregion

#region invoke SQL update procedure with 2 params
	
Function Invoke-SQLUpdateProcessProc($Server, $Database, $ProcedureName, $Param1Name,$Param1Value, $Param2Name, $Param2Value)
{
$SqlConnection = New-Object System.Data.SqlClient.SqlConnection
$SqlConnection.ConnectionString = "Server=$Server;Database=$Database;Integrated Security=True"
$SqlCmd = New-Object System.Data.SqlClient.SqlCommand
$SqlCmd.CommandText = $ProcedureName
$SqlCmd.Connection = $SqlConnection
$SqlCmd.CommandTimeout = 300 #300 5 minutes timeout
$SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
$Parameter1 = new-object System.Data.SqlClient.SqlParameter;
$Parameter1.ParameterName = $Param1Name;
$Parameter1.Value = $Param1Value;
$Parameter1.DbType = [System.Data.DbType]'Int32';
$SqlCmd.Parameters.Add($Parameter1);
$Parameter2 = new-object System.Data.SqlClient.SqlParameter;
$Parameter2.ParameterName = $Param2Name;
$Parameter2.Value = $Param2Value;
$Parameter2.DbType = [System.Data.DbType]'Int32';
$SqlCmd.Parameters.Add($Parameter2);

$SqlConnection.Open();
$result = $SqlCmd.ExecuteNonQuery();
#$output = $SqlCmd.Parameters[$OutputParamName].Value;
$SqlConnection.Close() | out-Null;
$SqlCmd.Dispose() | out-Null
$SqlConnection.Dispose() | out-Null;

#Return $output;
	}

	#endregion

#region invoke MFVersionUpdate
Function Invoke-MFVersionUpdate($Server,$Database)
{

$Query = "Select cast(value as nvarchar(100)) as Value from MFSettings where name = 'MFVersion'"

$MFVersion_Settings = Invoke-SQLQueryProc $Server $Database $Query
$MFVersion_Settings.Value

$CurrentVersion = get-currentMFilesVersion $MFVersion_Settings.value

$CurrentVersion.isCurrent
$CurrentVersion.Value

if($MFVersion_Settings.Value -ne $CurrentVersion.Value)
{
$ProcedureName = "spMFUpdateAssemblies"
$ReturnValue = Invoke-SQLNoParamProc $Server $Database $ProcedureName

$ReturnValue

}
}

#endregion

#region invoke UpdateAllTables
Function Invoke-UpdateAllTables($Server,$Database,$Param1,$Param2)
{

$ProcedureName = 'spMFUpdateAllncludedInAppTables'
$Param1Name = '@UpdateMethod'
$Param2Name = '@RemoveDeleted'

Try {

Add-ProcessLog ("In Progress: {0}" -f  $ProcedureName) $True $ProcessLog


$SQLProcOutput = Invoke-SQLUpdateProcessProc -Server $Server `
 -Database $Database `
 -ProcedureName $ProcedureName -Param1Name $Param1Name -Param1Value $Param1 -Param2Name $Param2Name -Param2Value $Param2

Add-ProcessLog ("Completed: {0}" -f  $ProcedureName) $True $ProcessLog

}Catch 
{ Add-ErrorLog "Unable to run update procedure: $_"  $True $ProcessLog
Add-ProcessLog ("Failed: {0}" -f  $ProcedureName) $True $ProcessLog
}

# log outcome



}

#endregion

#region invoke DeleteHistory
Function Invoke-DeleteHistory()
{

}

#endregion

#region get MFiles version from settings

Function Get-MFilesVersion()
{

$Procedure = "Select Value from MFSettings where Name = 'MFSettings'" 

}
