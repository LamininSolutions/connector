
# SQLSchedulermain.ps1
# Main process

Param([parameter(Mandatory=$true)][string]$SetupXML,`
[parameter(Mandatory=$true)][string]$Process)

If ($SetupXML -eq $null)
{ write-host 'Invalid file parapmeter'
exit}
write ("Setup file : {0}" -f $SetupXML)
#Pause


if ($PSVersionTable.PSVersion.Major -lt 5)
{ Write "Current version of Powershell is incompatiple, upgrade to version 5 or higher"
Exit
}


# region Include required files
#
$ScriptDirectory = Split-Path -Path $MyInvocation.MyCommand.Definition -Parent
try {

    . ("$ScriptDirectory\Library\SCH_Functions_Lib.ps1")
	. ("$ScriptDirectory\Library\SCH_SQL_Procs.ps1")
}
catch {
    Write-Host "Error while loading supporting PowerShell Scripts" 
    get-location
    exit
}
#endregion
Try {
$RootPath = Get-RootPath 
#write-host $RootPath
$Filename = Get-SetupFilePath $RootPath $SetupXML 

}
Catch
{ Write-Host "Unable to find XML"
}

#$filename

##setup application settings
$ApplicationSettings = Get-ApplicationSettings($Filename)


##Start logging
$Logging = Get-LoggingFolders $RootPath $ApplicationSettings.LogFolder 
$ErrorLog = $Logging[0]
$ProcessLog = $Logging[1]



Try {
	$Message = "Start Processing: "+$ApplicationSettings."Application"
Add-ProcessLog $Message $True $ProcessLog
$Message = ("Setup file : {0}" -f $SetupXML)
Add-ProcessLog $Message $True $ProcessLog

#$ApplicationSettings.Application
	}
	Catch
	{Write-Host "Unable to update log: $_"}

## invoke update procedure
if(get-Module -List | Where-Object -Property name -eq 'SqlServer')
{
#$ApplicationSettings.Server
Import-Module SQLSERVER
$Server = $ApplicationSettings.Server

Add-ProcessLog ("Connection to: {0}" -f  $Server) $True $ProcessLog

$Databases = $ApplicationSettings.Database
Foreach($item in $Databases)
{
$DBName = $Item.DBName
$ConnectionString = ("Data Source='{0}';Initial Catalog='{1}';Trusted_Connection=True;" -f $Server,$DBName)

#$Item.Process
$Processes = $Item.Process 

$TobeProcessed = $Item.Process | where-object {($_.name -eq $Process) -and  ([system.convert]::ToBoolean($_.IsIncluded) -eq $True)}
#write-host  $toBeProcessed.name

if((SqlServer\Get-SqlDatabase -ConnectionString $ConnectionString))
{
Add-ProcessLog ("Processing database: {0}" -f  $DBName) $True $ProcessLog

#Get-ProgressBar

write-host ("Processing {0} for Database {1}" -f $Process, $DBName)

if($Process -eq 'MFVersionUpdate') 
{

write-Host ("Updated MFVersion for {0}" -f $DBName)
Add-ProcessLog ("Updated MFVersion for {0}" -f $DBName) $True $ProcessLog

Invoke-MFVersionUpdate $Server $DBName

}

if($Process -eq 'DeleteHistory')
{
$Param1 = $toBeProcessed.Param1
write ("Deleted History for {0} with param {1}" -f $DBName, $Param1)
Add-ProcessLog ("Deleted History for {0} with param {1}" -f $DBName, $Param1) $True $ProcessLog
}

if($Process -eq 'UpdateAllTables') 
{
$Param1 = $toBeProcessed.Param1
$Param2 = $toBeProcessed.Param2

write ("Update All Tables for {0} with param1 {1} and param2 {2}" -f $DBName, $Param1, $Param2)

Add-ProcessLog ("Update All Tables for {0} with param1 {1} and param2 {2}" -f $DBName, $Param1, $Param2) $True $ProcessLog


Try {


Add-ProcessLog ("{0} : spMFUpdateAllIncludedinAppTables {1} {2}" -f $DBName, $Param1, $Param2) $True $ProcessLog

invoke-UpdateAllTables $Server $DBName $Param1 $Param2

Add-ProcessLog ("{0} : spMFUpdateAllIncludedinApp completed" -f $DBName, $Param1, $Param2) $True $ProcessLog

}Catch 
{ Add-ErrorLog "Unable to invoke update all tables: $_"  $True $ProcessLog
Add-ProcessLog ("Failed: {0}" -f  $ProcedureName) $True $ProcessLog
}

}
}else #if database exist
{
write-host ("{0} not found" -f $DBName )
}
} #foreach database

}Else
{ Write "SqlServer module is not installed - database tables not created"
}

exit



