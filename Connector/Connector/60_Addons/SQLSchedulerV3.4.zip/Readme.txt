MFSQL Connector utility
MFSQLScheduler for using windows task scheduler to process MFSQL Connector procedures
Copywrite 2019 Laminin Solutions
Version 3.1 27-4-2019

SUMMARY
This utility is intended as an alternative for using SQL Agent for scheduling MFQL Connector procedures
This is particularly relevant when using SQL Express for running the following processes for any number of databases in a server:
	.Automating the MFVersion update : MFVersionUpdate
	.Updating all class tables for reporting : UpdateAllTables
	.Deleting history : DeleteHistory


The utility can be included in windows task scheduler to be run with set intervals. Each Setup XML file points to a specific Server. The server can have multiple databases to be processed (e.g. production and test, or different vaults) and each database can have multiple predefined processes that can be scheduled in the task scheduler.    A separate bat file is required for each process. The following bat files are provided as examples.
MFSQLSchedule_UpdateAllIncludedInAppTables.bat for running spMFUpdateAllIncludedInAppTables with @UpdateMethod = 1, @Isdeleted = 1

The results of the most recent update is recorded in the processlog. \logs\processeslog.txt 
Any errors are recorded in the errorlog. \logs\errorlog.txt

PREREQUISITES
Powershell 5.0 + is required.
SQLServer module is required to access the SQL Server.  Use the PS script in /library to test and install this module.
Run with windows credentials with access to SQL and the MFSQL Connector database
The connection string is set to use windows integrated security. Run the bat file as administrator if the current user does not have admin rights and have execution rights on the SQL server and databases 

PACKAGE CONTENT
MFSQLScheduler_Main.ps1 : this is the main routine.  Use bat the execute each procedure.  Do not execute the ps1 file directly.
xxx.bat : used to execute the main routine. A separate bat is used for each procedure. Refer to the section below for modifying bat file.
SQLScheduler.XML : The main configuration file. A separate configuration file is required for each database. Refer to different section to setup.
\Library\ : the library contains the functions called by the main routine.
\Log\ : error and processing log. folder and files are created by utility.

SETUP
Open MFSQLScheduler.xml with notepad or a xml editor.
modify the SQLScheduler\ApplicationPath to match the filepath where this utility is saved.
modify SQLScheduler\TargetDB\Server to set the target server for the SQL destination
modify SQLScheduler\TargetDB\Database to set the name of the Database to export to and enable disable each process to be included. 
	The main application makes provision for setting up multiple databases and multiple processes per database
	DO NOT CHANGE the names of the processes. Only change the true / false for the IsIncluded attribute indicating if the process should be included for the specific database
	Each process has been setup to use default parameters. Changes to these parameters are unique to the underlying procedure and should only be changed in exceptional cases.
	The sample XML include sample data, including a sample second database for illustration. Delete the extra database node if you are not using multiple databases.

BAT FILE
Use a separate bat file for each process. The app include sample bat files for the processes that can be used.
Open bat file with notepad 
modify the string after -Command to reference the path of the main routine + setupfilename + processname 
spaces and case matters.

Example:
E:\Development\TFS\LSApplications\Powershell_Apps\SQLScheduler\MFSQLScheduler_Main.ps1 MFSQLScheduler.xml UpdateAllTables"

WINDOWS TASK SCHEDULER
To schedule the process to run automatically at predefined intervals - execute the bat file using the standard windows task scheduler setup.  Run the bat file with windows permission as outlined above.

TO INSTALL MODULES
Run \library\FE_Module_install in powershell as administrator



